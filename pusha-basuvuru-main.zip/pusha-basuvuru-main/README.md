

Botu Başlatmak İçin Yapmanız Gerekenler;

* `Settings/config.js` dosyasını doldurmanız ve modülleri indirmeniz gerekmektedir.

Config.json Dosyasının İçi;
```
    "BotToken":"Botunuzun Tokeni",
    "OwnerID":"Bot Yapımcısının IDsi", 
    "prefix":"Botun Prefixi",

    "BotVoiceChannel":"Botun Gireceği Ses Kanalı ID",
    "Activity":"Botun Durumu",

    "Footer":"Log Kanalına Atacağı Embedin Altında Yazan Yazı",
    "Color":"Embedin Rengi",
    "TikID":"Tik Emoji ID",
    "CarpiID":"Çarpı Emoji ID",

    "Staff":"Her Yetkilide Olan Yetki ID",
    "StaffRoleID":"Yetkili Alım İçin DM Rolünün IDsi",
    "TagRoleID":"Taglı Rolünüzün IDsi",
    "CCID":"Komutun Kullanılacağı Kanalın IDsi",
    "LogChannelID":"Başvuru Loglarını Atacağı Kanal IDsi",
    "KategoryID":"Başvuru Kanallarının Açılacağı Kategori IDsi",
    "EveryoneID":"Rollerdeki Everyone IDsi"
```
Discord Sunucumuz discord.gg/theaspendos yazarak bana ulasa bılırsınız