let obj = {
    "sunucuID": "774977651429212181",
    "mainToken": "ana bot token",
    "prefix": ".",
    "tokens": ["rol dagıtacak bot tokenlerını gırecenız la ıstedıgınız kadar",],
	
    "helperBotActivity":"ASPENDOS ❤️ PUSHA",
    "mongodb": "mongo url gır amcık bır zahmet",
    "action": "BAN", //BURAYA: ( BAN | JAIL | KICK  | MUTE ) YAZILABİLİR
    "actionRoleId": ["882755240728854558","882755238359089204"], //BURAYA JAIL VE YA MUTE ROLÜNÜN İDSİ KOYULABİLİR (İSTEĞE BAĞLI)
    "Durum": "ASPENDOS ❤️ PUSHA", 
    "status":"dnd",
    "logChannelId": "882772685896183928", //İŞLEMLERİN KAYIT EDİLECEĞİ KANAL ID
    "whitelistMembers": ["682116946489114635","882795954711965746","882796712769486920","887729477357010944","882791157812310046","882791342621724752","882791554736087081","887729541596999811","758965145166282773","692122007449632818","783186240883130418","801483874051817523","801483981249970206","802530996335280178","848657463033069590","783185168965304330","883355938587828275"], //GÜVENLİ LİSTEDEKİ KULLANICILARIN 
    "BotVoiceChannels":""
};

module.exports = obj;