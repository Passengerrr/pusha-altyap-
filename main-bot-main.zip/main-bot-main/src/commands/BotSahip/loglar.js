
module.exports = {
  conf: {
    aliases: ["ready","hazır","aris"],
    name: "ready",
    owner: true,
  },

  run: async (client, message, args) => {
message.lineReply(`Her zaman Aris kral!`)
}}